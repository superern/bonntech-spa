export class User {
    id: number;
    firstname: string;
    lastname: string;
    mobile: string;
    postcode: string;
    email: string;
}
